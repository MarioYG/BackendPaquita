define({
  "title": "PAQUITA ",
  "url": "https://sunatcodeblack.mybluemix.net",
  "name": "PAQUITA BACKEND",
  "version": "4.6.9",
  "description": "Documentacion de Servicios ",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-02-19T03:54:17.572Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
